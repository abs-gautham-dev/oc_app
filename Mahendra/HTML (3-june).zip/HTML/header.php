<header>
<div class="container">
    <div class="row">
        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-5 text-left">
            <a href="index.php" class="logo"><img src ="./assets/img/logo.png"> Office <span>checkers</span></a>
            <a href="#" class="cell-phone"><i class="fa fa-phone"></i> +447774018889  </a>
        </div>
        <div class="col-xs-12 col-sm-7 col-md-7 col-lg-7 text-right">
        <div class="topnav" id="myTopnav"> 
            <a href="#news" class="active">Book Inspector</a>
            <a href="#contact">Pricing</a>
            <a href="#about">Faq’s</a>
            <a href="#about">News</a>
            <a href="#about">About us</a>
            <a href="#about">Contact us</a>
            <div class="dropdown">
              <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Login As
              <span class="caret"></span></button>
              <ul class="dropdown-menu">
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
              </ul>
            </div>
            <a href="javascript:void(0);" class="icon" onclick="myFunction()">
            <i class="fa fa-bars"></i>
            </a>
        </div>
        </div>
 <div>
</div>       
</header>

