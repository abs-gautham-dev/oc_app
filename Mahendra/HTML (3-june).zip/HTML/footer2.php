<footer>
    <div class="container footer-container">
        <div class="footer-content footer-logo">
            <a href="index.html" class="logo"><img src ="./assets/img/logo.png"><br> Office <span>checkers</span></a>
            <a href="#" class="cell-phone"><i class="fa fa-phone"></i> +447774018889  </a>
            <ul class="social-icon mobile">
                <li> <a href="#"><i class="fa fa-facebook"></i>  </a> </li>
                <li> <a href="#"><i class="fa fa-twitter"></i>  </a> </li>
                <li> <a href="#"><i class="fa fa-linkedin"></i>  </a> </li>
            </ul>
        </div>
        <div class="footer-content mobOrder">
            <a href="#" class="first">Right Jobs  </a>
            <a href="#">About  </a>
            <a href="#">News  </a>
            <ul class="social-icon desktop">
                <li> <a href="#"><i class="fa fa-facebook"></i>  </a> </li>
                <li> <a href="#"><i class="fa fa-twitter"></i>  </a> </li>
                <li> <a href="#"><i class="fa fa-linkedin"></i>  </a> </li>
            </ul>
        </div>
        <div class="footer-content">
            <a href="#" class="first">Employers  </a>
            <a href="#">Account  </a>
            <a href="#">Find Job   </a>
            <a href="#">Post Jobs </a>
            <a href="#">Registration  </a>
        </div>
        <div class="footer-content">
            <a href="#" class="first">Important  </a>
            <a href="#">Help/Contact us</a>
            <a href="#">Privacy Policy  </a>
            <a href="#">Terms of use  </a>
            <a href="#">Privacy Policy  </a>
        </div>
    </div>
    <div class="copyright-section">
        <div class="container">
            <div class="copyrightBlock">
                <span><a href="#" class="copyright-mail">Officecheckers@gmail.com | www.officecheckers.com </a></span>
                <span><a href="#" class="copyright">All rights reserved @ 2020 Office Checkers (UK) Ltd.</a></span>
            </div>
        </div>
    </div>
</footer>